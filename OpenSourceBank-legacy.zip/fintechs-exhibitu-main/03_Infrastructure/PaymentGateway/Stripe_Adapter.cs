// fintechs-exhibitu/03_Infrastructure/PaymentGateway/Stripe_Adapter.cs
