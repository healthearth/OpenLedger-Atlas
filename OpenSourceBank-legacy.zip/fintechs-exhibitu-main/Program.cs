// fintechs-exhibitu/Program.cs
