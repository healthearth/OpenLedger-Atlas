// fintechs-exhibitu/GlobalUsings.cs
// © 2026 Andrew Kieckhefer. All rights reserved. 

global using System;
global using System.Threading.Tasks;

global using GlobalBank.Domain.Entities;
global using GlobalBank.Domain.Interfaces;
